# V0.7.3.1 ONLINE — PLAYER MOVEMENT HOTFIX

Date: 2026-09-24  
Candidate: `V0.7.3.1-ONLINE-PLAYER-MOVEMENT-HOTFIX.html`  
SHA-256: `D196C17AF38BA52BB8846E7384D881A9EC93DD9AB6412D0ACC3C8CB66AC1627A`  
Size: 306,203 bytes  
Browser: Chromium, desktop 1000×740 and phone-size 390×740; responsive UI regression also covered 320×640, 844×390 and 1280×800.

## What changed

The guest previously ran `stepPlayer` locally, but local walking, the host snapshot, and rendering all wrote to the same `player.p`. A delayed snapshot could overwrite fresh local movement; there was no acknowledged-input replay for courier walking. The guest also added the same host actor snapshot to its interpolation buffer every animation frame, so repeated copies of one sample crowded out useful history. Cargo positions were already stored in van-local coordinates, but the network actor payload did not label that coordinate space.

This release adds `reconcileGuestPlayer` and `stepGuestPlayer`: the guest retains authoritative and predicted courier state, trims input records through `ackInput`, replays later input states, and renders predicted position plus a decaying correction offset. Cargo actors carry `space: cargo-local`; outside actors carry `space: world`. Boarding/exit and role transitions reset the buffer at the boundary. `recordHostActorSnapshot` now records only newly received snapshots; `sampleHostActor` interpolates pose fields and limits extrapolation. `updateStick`, `turnLook`, key events and `sendInputNow` send material input changes promptly while local movement never waits for a network response.

The host still simulates authoritative player collision and all shared game effects. Inputs continue to use increasing sequences, stale sequences are rejected, and the 50ms heartbeat still clears a lost held state after timeout.

## Tests

| Suite | Result |
|---|---:|
| TURN route diagnostic and deadline/recommendation checks | 11 / 11 |
| Network settings, relay controls and credential redaction | 24 / 24 |
| Online HUD and responsive city-map UI | 13 / 13 |
| Two-client roles, authority, pickup/drop, delivery, repair and doors | 30 / 30 |
| Desktop/mobile layout, touch streams and boot | 32 / 32 |
| Solo play, packages, repair, garage and delivery | 31 / 31 |
| City traffic and signals | 24 / 24 |
| Extended city, map and two-client sync | 26 / 26 |
| Full 18-delivery round and settlement | 21 / 21 |
| **Existing gameplay/network regression** | **212 / 212** |
| Prior vehicle prediction/network-delay regression | 32 / 32 |
| Courier movement short-delay, joystick, buffering, role/world round-trip and forced-correction checks | 26 / 26 |
| Real-time 400ms long-run movement scenario | 1 / 1 |
| **Movement checks including long run** | **27 / 27** |

The existing two-client suite had one door-angle timing miss on its first run; its isolated rerun passed 30/30. No code change was required for that timing-only result.

## Delay and movement results

The guest’s first rendered movement frame advanced 0.125m in every short scenario. With the host van simultaneously travelling and turning, the final authoritative courier-position gap after release was 0.000m. One startup/epoch alignment hard correction was counted in each ordinary case; no additional hard corrections occurred during regular movement.

| Configured RTT | Jitter | Dropped replaceable packets | Mean / max reconciliation error | Host/guest gap after release | Joystick movement / release drift |
|---:|---:|---:|---:|---:|---:|
| 0ms | 0ms | 1 / 64 | 0.014m / 0.191m | 0.000m | 0.100m / 0.000m |
| 100ms | 22ms | 1 / 73 | 0.035m / 0.189m | 0.000m | 0.100m / 0.000m |
| 250ms | 22ms | 1 / 73 | 0.023m / 0.191m | 0.000m | 0.100m / 0.000m |
| 400ms | 22ms | 1 / 72 | 0.050m / 0.300m | 0.000m | 0.100m / 0.000m |

A separate 308.2-second two-client run used 400ms configured RTT, 22ms jitter, and deterministic 2% replaceable-message loss: 90 of 4,514 replaceable packets were dropped (1.99%). Maximum/mean reconciliation error was 0.765m / 0.086m; the largest sampled host/guest position gap was 0.550m and fell to 0.000m after release. Input history peaked at 6 unacknowledged records, the remote snapshot buffer stayed at its 12-sample cap, and the only hard correction was initial connection alignment. Both Chromium pages completed without runtime errors. The van travelled 125.67m during this run.

An explicit 4.83m authoritative relocation produced one additional hard correction and immediate predicted/authoritative convergence. Twenty cargo-local/world boarding cycles accumulated 0m measured world-space and cargo-local drift. A separate 300-second equivalent fixed-step mobile movement run completed 18,000 steps with input history capped at 256 and snapshot history at 12.

## Limits

The configured 0–400ms RTT values, 22ms jitter and packet loss are simulated by an ordered in-page test bridge, not WebRTC. These checks do not claim that a real TURN RTT is lower, and do not verify live Cloudflare relay allocation or physical-device pairing. The existing six-route ICE test uses synthetic relay candidates. Final production acceptance still requires the user’s live `game.feelpal.app` ICE check and Wi-Fi ↔ iPhone 5G test.

## Release files

- `index.html` — final single-file release at repository root
- `V0.7.3.1-ONLINE-PLAYER-MOVEMENT-HOTFIX.zip`
- `V0.7.3.1-CHANGELOG.md`
- `V0.7.3.1-TEST_REPORT.md`
- `V0.7.3.1-MOVEMENT-RESULTS.json`
