# V0.7.3.1 ONLINE — PLAYER MOVEMENT HOTFIX

- Guest courier walking now simulates locally each frame and replays unacknowledged sequenced input after host snapshots.
- Authoritative, predicted, and rendered courier positions are separated. Small and medium network corrections are applied through a bounded render offset; hard correction is reserved for space/role/epoch transitions and severe position divergence.
- Cargo snapshots explicitly identify vehicle-local coordinates; outside snapshots use world coordinates. Cargo motion therefore does not reconcile against the van’s world-space movement.
- Remote teammate snapshots are captured once per received world update and buffered to 12 samples. Position, shortest-path yaw, pitch, walk phase, movement, animation and held-package state are interpolated; extrapolation stops at 160ms.
- Keyboard state changes and joystick press, material direction changes, and release send immediately. The existing 50ms input heartbeat remains; releasing local controls stops local movement without waiting for the host.
- Host authority remains responsible for collisions, parcel inventory, pickup/drop/delivery, repair, doors, role changes, orders and score.
- V0.7.3 low-latency vehicle prediction, Cloudflare TURN, six-route ICE diagnostics, city traffic and existing gameplay remain in the release.
- Development movement diagnostics are available only through the opt-in test fixture. No TURN credentials or Cloudflare secrets are included.

## Verification boundary

The 0/100/250/400ms checks and 308.2-second 400ms run use a deterministic in-page transport bridge. They test simulated delay, jitter and packet loss; they do not measure or lower real RTT and do not prove live Cloudflare TURN allocation.
